//
//  VenueListViewModel.swift
//  PPe
//
//  Created by Vikhyath Shetty on 25/11/23.
//

import Foundation

class VenueListViewModel {
    
    // Constants
    private var pageNumber = 0
    private var range = 10
    
    private let networkService: NetworkService
    private let storage: VenueStorage
    private(set) var state: APIState = .loading
    
    init(
        state: APIState = .loading,
        service: NetworkService = DefaultNetworkService(),
        storage: VenueStorage = VenueListCoreDataStorage()
    ) {
        self.networkService = service
        self.state = state
        self.storage = storage
    }
    
    func fetchVenues(completion: @escaping (VenueData) -> Void) {
        
        pageNumber += 1
        
        let request = VenueRequest.getRequest(pageNumber: pageNumber, range: range)
        
        // if cached data is present -> fetch it and show it on UI else show a loader.
        if let cachedData = storage.fetchFromDB() {
            completion(VenueData(state: .success, data: cachedData))
        } else {
            completion(VenueData(state: .loading, data: nil))
        }
        
        
        /*
         
         // After cached data is shown the api call is made.
         networkService.request(request) { [weak self] result in

             switch result {
             case .success(let data):
                 DispatchQueue.main.async { completion(VenueData(state: .success, data: data)) }
                 // store the new in the cache
                 self?.storage.saveToLocalDB(data)
             case .failure(let failure):
                 DispatchQueue.main.async { completion(VenueData(state: .failure("Failed to load data"), data: nil)) }
                 print(failure.localizedDescription)
             }
         }
         
         */
       
        
        // Since API was not working because of this: -
        // An SSL error has occurred and a secure connection to the server cannot be made.
        // Tried to fix it by adding NSAppTransportSecurity in plist didn't work for some reason :(
        let list = Bundle.main.decode(VenueList.self, from: "Mock.json")
        print(list)
        
        completion(VenueData(state: .empty, data: list))
    }
    
    // Pagination was not handled because of this issue.
    // An SSL error has occurred and a secure connection to the server cannot be made.
    // Tried to fix it by adding NSAppTransportSecurity in plist didn't work for some reason :(
    
    func fetchNextPageData(completion: @escaping (VenueData) -> Void) {
        
        let request = VenueRequest.getRequest(pageNumber: pageNumber, range: range)
        
        completion(VenueData(state: .loading, data: nil))
        
        networkService.request(request) { [weak self] result in

            switch result {
            case .success(let data):
                DispatchQueue.main.async { completion(VenueData(state: .success, data: data)) }
            case .failure(let failure):
                DispatchQueue.main.async { completion(VenueData(state: .failure("Failed to load data"), data: nil)) }
                print(failure.localizedDescription)
            }
        }
    }
}

