//
//  NetworkRequest.swift
//  PPe
//
//  Created by Vikhyath Shetty on 25/11/23.
//

import Foundation

class VenueRequest: DataRequest {
    
    typealias Response = VenueList
    
    private let queryparams: [String: Any]
    
    var queryItems: [String: Any] {
        return queryparams
    }
    
    var url: String {
        
        let baseURL = "https://api.seatgeek.com/"
        let path = "2/venues"
        return baseURL + path
    }
    
    var method: HTTPMethod {
        .get
    }
    
    init(params: [String: Any]) {
        self.queryparams = params
    }
}


extension VenueRequest {
    
    static func getRequest(pageNumber: Int, range: Int) -> VenueRequest {
        
        return VenueRequest(params: [
        
            "cleint_id": Constants.clientId,
            "per_page": Constants.defaultPerPageData,
            "page": pageNumber,
            "lat": Constants.currentLocation.lat,
            "lon": Constants.currentLocation.long,
            "range": range
        ])
    }
}
