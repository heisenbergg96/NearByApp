//
//  VenueDisplayCell.swift
//  PPe
//
//  Created by Vikhyath Shetty on 25/11/23.
//

import Foundation
import UIKit

class VenueDisplayCell: UITableViewCell {
    
    private let label = UILabel()
    private let subtitle = UILabel()
    private let stack = UIStackView()
    private let containerView = UIView()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        addSubview(containerView)
        containerView.fillSuperview()
        
        stack.addArrangedSubview(label)
        stack.addArrangedSubview(subtitle)
        stack.axis = .vertical
        stack.distribution = .fill
        stack.alignment = .fill
        stack.spacing = 8
        
        subtitle.textColor = .lightText
        subtitle.font = UIFont.systemFont(ofSize: 12)
        
        containerView.addSubview(stack)
        
        containerView.backgroundColor = .tertiarySystemBackground
        
        stack.anchor(
            
            top: containerView.topAnchor,
            bottom: containerView.bottomAnchor,
            left: containerView.leadingAnchor,
            right: containerView.trailingAnchor,
            padding: UIEdgeInsets(top: 16, left: 16, bottom: 16, right: 16)
        )
    }
    
    func populateCellUI(_ venue: Venue) {
        label.text = venue.name
        subtitle.text = venue.address
        label.isHidden = venue.name.isEmpty
        subtitle.isHidden = venue.address?.isEmpty ?? true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
