//
//  Repository.swift
//  PPe
//
//  Created by Vikhyath Shetty on 25/11/23.
//

import Foundation

protocol VenueStorage {
    func saveToLocalDB(_ list: VenueList)
    func fetchFromDB() -> VenueList?
}

// TODO: - Because of lack of time couldnt implement local caching
class VenueListCoreDataStorage: VenueStorage {
    
    func saveToLocalDB(_ list: VenueList) {
        // Save to local DB
    }
    
    func fetchFromDB() -> VenueList? {
        return Bundle.main.decode(VenueList.self, from: "Mock.json")
    }
}

class VenueListFileSystemStorage: VenueStorage {
    
    func saveToLocalDB(_ list: VenueList) {
        // Save to local DB
    }
    
    func fetchFromDB() -> VenueList? {
        return Bundle.main.decode(VenueList.self, from: "Mock.json")
    }
}
