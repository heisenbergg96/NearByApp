//
//  ViewController.swift
//  PPe
//
//  Created by Vikhyath Shetty on 25/11/23.
//

import UIKit

class HomeViewController: UIViewController {
    
    private let tableView = UITableView(frame: .zero)
    private var venueData: VenueList?

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        
        VenueListViewModel().fetchVenues {  [weak self] data in
            self?.handleUI(with: data)
        }
    }
    
    private func setupUI() {
        view.addSubview(tableView)
        tableView.fillSuperview()
        tableView.register(VenueDisplayCell.self, forCellReuseIdentifier: "VenueDisplayCell")
        navigationController?.navigationBar.prefersLargeTitles = true
        title = "Venues"
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    private func handleUI(with data: VenueData?) {
        
        let state = data?.state ?? .loading
        
        switch state {
        case .failure(let string):
            tableView.reloadData()
            tableView.backgroundView = BaseBackgroundView(text: string)
        case .loading:
            tableView.backgroundView = BaseBackgroundView(text: "loading")
        default:
            break
        }
        
        if let data {
            venueData = data.data
            tableView.reloadData()
        }
    }
}

// MARK: - UITableViewDataSource
extension HomeViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return venueData?.venues.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "VenueDisplayCell", for: indexPath) as! VenueDisplayCell
        
        if let venue = venueData?.venues[indexPath.row] {
            cell.populateCellUI(venue)
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}

extension HomeViewController: UITableViewDelegate {
    
}



