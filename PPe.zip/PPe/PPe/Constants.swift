//
//  Constants.swift
//  PPe
//
//  Created by Vikhyath Shetty on 25/11/23.
//

import Foundation

class Constants {
    static let clientId = "Mzg0OTc0Njl8MTcwMDgxMTg5NC44MDk2NjY5"
    static let defaultPerPageData = 10
    static let currentLocation = CurrentLocation(lat: "12.971599", long: "77.594566")
}

struct CurrentLocation {
    let lat: String
    let long: String
}
