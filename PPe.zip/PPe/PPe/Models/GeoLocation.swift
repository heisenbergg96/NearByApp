//
//  GeoLocation.swift
//  PPe
//
//  Created by Vikhyath Shetty on 25/11/23.
//

import Foundation

// MARK: - VenueList
struct VenueList: Codable {
    let venues: [Venue]
    let meta: Meta
}

// MARK: - Meta
struct Meta: Codable {
    let total, took, page, perPage: Int
    let geolocation: Geolocation

    enum CodingKeys: String, CodingKey {
        case total, took, page
        case perPage = "per_page"
        case geolocation
    }
}

// MARK: - Geolocation
struct Geolocation: Codable {
    let lat, lon: Double
    let city, state, country, postalCode: String
    let displayName: String
    let metroCode: String?
    let range: String

    enum CodingKeys: String, CodingKey {
        case lat, lon, city, state, country
        case postalCode = "postal_code"
        case displayName = "display_name"
        case metroCode = "metro_code"
        case range
    }
}

// MARK: - Venue
struct Venue: Codable {
    let nameV2, postalCode, name: String
    let timezone: String?
    let url: String
    let score: Int
    let location: Location
    let address: String?
    let country: Country
    let hasUpcomingEvents: Bool
    let numUpcomingEvents: Int
    let city: City
    let slug: String
    let extendedAddress: DisplayLocation
    let stats: Stats
    let id, popularity: Int
    let metroCode, capacity: Int
    let displayLocation: DisplayLocation

    enum CodingKeys: String, CodingKey {
        case nameV2 = "name_v2"
        case postalCode = "postal_code"
        case name, timezone, url, score, location, address, country
        case hasUpcomingEvents = "has_upcoming_events"
        case numUpcomingEvents = "num_upcoming_events"
        case city, slug
        case extendedAddress = "extended_address"
        case stats, id, popularity
        case metroCode = "metro_code"
        case capacity
        case displayLocation = "display_location"
    }
}

enum City: String, Codable {
    case bangalore = "Bangalore"
    case bengaluru = "Bengaluru"
}

enum Country: String, Codable {
    case india = "India"
}

enum DisplayLocation: String, Codable {
    case bangaloreIndia = "Bangalore, India"
    case bengaluruIndia = "Bengaluru, India"
}

// MARK: - Location
struct Location: Codable {
    let lat, lon: Double
}

// MARK: - Stats
struct Stats: Codable {
    let eventCount: Int

    enum CodingKeys: String, CodingKey {
        case eventCount = "event_count"
    }
}


struct VenueData {
    let state: APIState
    let data: VenueList?
}
